// namespace MasjidBandung.Extensions;
//
// public static class RangeExtension {
//     public static IList<int> ToList(this Range range) {
//         var list = new List<int>();
//         for (int i = range.Start.Value; i < range.End.Value; i++) {
//             list.Add(i);
//         }
//
//         return list;
//     }
// }
