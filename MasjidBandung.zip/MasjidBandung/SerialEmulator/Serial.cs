namespace SerialEmulator; 

public class Serial {
    
}