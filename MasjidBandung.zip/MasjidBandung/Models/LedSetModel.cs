﻿namespace MasjidBandung.Models;

public class LedSetModel {
    public double Value { get; set; }
}
