global using Microsoft.AspNetCore.Mvc;

global using MasjidBandung.Controllers;
global using MasjidBandung.Services;